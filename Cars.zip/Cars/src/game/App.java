package game;

public class App {
    public static void main(String[] args) throws Exception {
        Juego inicio = new Juego();
        inicio.run();
    }
}
